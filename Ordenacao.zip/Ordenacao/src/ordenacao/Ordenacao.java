/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ordenacao;

import java.util.List;
import java.util.Random;
import java.util.Vector;

/**
 *
 * @author laboratorio
 */
public class Ordenacao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Metodos m = new Metodos();
        m.criarVetor();
        m.ordenarVetor();
    }

}
